//
//  ViewController.swift
//  Activities
//
//  Created by Rp on 21/01/19.
//  Copyright © 2019 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet var tblview : UITableView!
    @IBOutlet var topView : UIView!
    
    var arrTitle = ["Recommended for you","Activies","Resturants"]
    var arrImage1 = ["reslo2","reslo3","reslo","evlo2"]
    var arrImage2 = ["evlo2","reslo3","evlo","evlo2"]
    var arrImage3 = ["reslo2","reslo3","reslo","evlo2"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let arrSlideImage = NSMutableArray()
        var arrTopImage = ["first","second","third","fourth"]
        
        for index in 0..<3
        {
            let slide = JOLImageSlide()
            slide.image = arrTopImage[index]
            arrSlideImage.add(slide)
        }
        
        let imageSlider = JOLImageSlider.init(frame: CGRect.init(x: 0, y: 0, width: self.topView.frame.size.width, height:topView.frame.size.height), andSlides: arrSlideImage as! [Any])
        imageSlider?.autoSlide = true
        self.topView.addSubview(imageSlider!)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let collectionView = cell.contentView.viewWithTag(1001) as! UICollectionView
        collectionView.delegate = self
        collectionView.dataSource = self

        
        collectionView.accessibilityLabel = "\(indexPath.section)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = Bundle.main.loadNibNamed("HeaderView", owner: self, options: [:])?.last as! HeaderView
        
        headerView.lblTitle.text = arrTitle[section]
        
        headerView.btnMore.addTarget(self, action: #selector(clickOnMore), for: .touchUpInside)
        
        return headerView
    }

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
     
        return 4
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellcollection", for: indexPath)
        
        cell.layer.borderWidth = 1
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.cornerRadius = 5
        cell.layer.masksToBounds = true
       
        let imgView = cell.contentView.viewWithTag(1002) as! UIImageView
        
        if collectionView.accessibilityLabel == "0"
        {
            
            imgView.image = UIImage.init(named: arrImage1[indexPath.item])
        }
        else if collectionView.accessibilityLabel == "1"
        {
            
            imgView.image = UIImage.init(named: arrImage2[indexPath.item])
        }
        else{
            
            imgView.image = UIImage.init(named: arrImage3[indexPath.item])
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = CGSize.init(width: 100, height: 100)
        return size
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 10, left: 20, bottom: 10, right: 20)
    }
    
    @objc func clickOnMore(){
        
        let activies = self.storyboard?.instantiateViewController(withIdentifier: "ActivitiesResturantsVC") as! ActivitiesResturantsVC
        self.navigationController?.pushViewController(activies, animated: true)
    }


}

