//
//  ActivitiesResturantsVC.swift
//  Activities
//
//  Created by Rp on 21/01/19.
//  Copyright © 2019 Rp. All rights reserved.
//

import UIKit

class ActivitiesResturantsVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet var tblViewActivies : UITableView!
    @IBOutlet var tblViewResturants : UITableView!
    @IBOutlet var lblUnderline : UILabel!
    @IBOutlet var scrollView : UIScrollView!
    
   @IBOutlet  var width : NSLayoutConstraint!

    var arrImg1 = ["enter","sports","games","startup","managers","second1","first1","second1","first1"]
    
    var arrImg2 = ["enter","sports","games","startup","managers","second1","first1"]
    
    var arr = ["Entertainment : Funand Joy with the various things","Sports : Football,Cricket,Basket Ball,Volley Ball and too much for fun....","Meetups : Relatives,Friends,Strangers,Technocrats,Businessmen etc.....","Social Events","Startup Gatherings","Hackathons","School Geeks","Managers Desk","Dream Games"]
    
    var arr2 = ["Saudi Cuisine","Indian Recipe","Dubai Cooks","Chinese Grills","Indonesian Restuarant","British Foods","South African Dishes"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tblViewActivies.separatorStyle = .none
        tblViewActivies.tableFooterView = UIView()
        
        tblViewResturants.separatorStyle = .none
        tblViewResturants.tableFooterView = UIView()
        
       // width.constant = 2.0 * self.view.frame.size.width
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == tblViewActivies{
            
            return self.arrImg1.count
            
        }else{
            
            return self.arrImg2.count
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == tblViewActivies{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            
            let mainView = cell.contentView.viewWithTag(1000) as UIView?
            
            mainView?.layer.cornerRadius = 5
            mainView?.layer.shadowColor = UIColor.lightGray.cgColor
            mainView?.layer.shadowOpacity = 1
            mainView?.layer.shadowOffset = CGSize.zero
            mainView?.layer.shadowRadius = 2
            mainView?.layer.masksToBounds = false
            
            let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
            let lblGame = cell.contentView.viewWithTag(1002) as! UILabel
            
            let lblSubTitle = cell.contentView.viewWithTag(1003) as! UILabel
            
            imgView.image = UIImage.init(named: arrImg1[indexPath.row])
            lblGame.text = arr[indexPath.row]
            lblSubTitle.text = "Subtitle item"
            
            cell.selectionStyle = .none
            return cell
        }
        else{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellSecound", for: indexPath)
            
            let mainView = cell.contentView.viewWithTag(1000) as UIView?
            
            mainView?.layer.cornerRadius = 5
            mainView?.layer.shadowColor = UIColor.lightGray.cgColor
            mainView?.layer.shadowOpacity = 1
            mainView?.layer.shadowOffset = CGSize.zero
            mainView?.layer.shadowRadius = 2
            mainView?.layer.masksToBounds = false
            
            let imgView = cell.contentView.viewWithTag(1001) as! UIImageView
            let lblGame = cell.contentView.viewWithTag(1002) as! UILabel
            
            let lblSubTitle = cell.contentView.viewWithTag(1003) as! UILabel
            
            imgView.image = UIImage.init(named: arrImg2[indexPath.row])
            lblGame.text = arr2[indexPath.row]
            lblGame.numberOfLines = 0
            lblGame.sizeToFit()
            lblSubTitle.text = "Subtitle item"
            
            cell.selectionStyle = .none
            return cell
        }

    }
    
    @IBAction func clickOnActivies(){
        
        UIView.animate(withDuration: 0.5) {
            
            self.scrollView.contentOffset = CGPoint.init(x: 0, y: self.scrollView.contentOffset.y)
            
            var frame = CGRect()
            frame = self.lblUnderline.frame
            frame.origin.x = 0
            self.lblUnderline.frame = frame
        }
        
    }
    
    @IBAction func clickOnResturants(){
        
        UIView.animate(withDuration: 0.5) {
            
            self.scrollView.contentOffset = CGPoint.init(x: self.view.frame.size.width, y: self.scrollView.contentOffset.y)
            
            var frame = CGRect()
            frame = self.lblUnderline.frame
            frame.origin.x = self.view.frame.size.width/2
            self.lblUnderline.frame = frame
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
